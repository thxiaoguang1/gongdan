const state={
    startTime:'',
    endTime:'',
    danhao:'',
    name:'',
    duixiang:'',
    dizhi:'',
    time:'',
}
const getters={
    getStartTime(state){
        return state.startTime
    },
    getEndTime(state){
        return state.endTime
    },
    getdanhao(state){
        return state.danhao
    },
    getname(state){
        return state.name
    },
    getduixiang(state){
        return state.duixiang
    },
    getdizhi(state){
        return state.dizhi
    },
    gettime(state){
        return state.time
    },
}
const mutations= {
    addStartTime(state,startTime){
      state.startTime=startTime;
    },
    addEndTime(state,endTime){
        state.endTime=endTime;
    },
    adddanhao(state,danhao){
        state.danhao=danhao;
    },
    addname(state,name){
        state.name=name;
    },
    addduixiang(state,duixiang){
        state.duixiang=duixiang;
    },
    adddizhi(state,dizhi){
        state.dizhi=dizhi;
    },
    addtime(state,time){
        state.time=time;
    },
   
};
const actions={
    addStartTime(state,startTime){
        state.commit('addStartTime',startTime)
    },
    addEndTime(state,endTime){
        state.commit('addEndTime',endTime)
    },
    adddanhao(state,danhao){
        state.commit('adddanhao',danhao)
    },
    addname(state,name){
        state.commit('addname',name)
    },
    addduixiang(state,duixiang){
        state.commit('addduixiang',duixiang)
    },
    adddizhi(state,dizhi){
        state.commit('adddizhi',dizhi)
    },
    addtime(state,time){
        state.commit('addtime',time)
    }
}
export default {state,getters,mutations,actions}