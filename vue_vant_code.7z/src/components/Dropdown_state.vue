<template>
  <div>
    <van-field
      label="维修状态"
      readonly
      :value='value'
      placeholder="请选择状态"
      @click="showPicker = true"
      input-align='center'
    />  
    <van-popup v-model="showPicker" position="bottom" round get-container="#app">
      <van-picker
        show-toolbar
        :columns="columns"
        @cancel="showPicker = false"
        @confirm="onConfirm"
      />
    </van-popup>
  </div>   
</template>

<script>
import Vue from 'vue'
import { Field, CellGroup, Cell, RadioGroup, Radio, Collapse, CollapseItem, DatetimePicker, Popup, Button, Picker } from 'vant';
export default {
   components: {
    [Field.name]: Field,
    [CellGroup.name]: CellGroup,
    [Cell.name]: Cell,
    [Radio.name]: Radio,
    [RadioGroup.name]: RadioGroup,
    [Collapse.name]: Collapse,
    [CollapseItem .name]: CollapseItem,
    [DatetimePicker.name]: DatetimePicker,
    [Popup.name]: Popup,
    [Button.name]: Button,
    [Picker.name]: Picker,
  },
  props:['newButton','placeholder','label'],
  // props:{
  //   newButton:{
  //     type: String
  //   },
  //   placeholder:{
  //     type: String
  //   }
  // },
  name: 'dropdownState',
  data () {
    return {
      username:'',
      message:'',
      value:'',
      showPicker: false,
      columns:['已完成', '取走处理', '返厂处理'],
      activeNames: ['0'],
      radio: '1',
      // msg: 'Welcome to Your Vue.js App'
    }
  },
  methods: {
    onConfirm(value){
      this.value=value;
      this.showPicker = false;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
 .button{
   margin-top:25px;
 }
</style>
