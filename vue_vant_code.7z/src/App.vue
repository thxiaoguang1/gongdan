<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
import store from './store'
export default {
  name: 'App',
  store,
}
</script>

<style>
</style>
